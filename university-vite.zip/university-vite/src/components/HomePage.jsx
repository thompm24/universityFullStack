function HomePage() {
  return (
    <div className="m-20">
      <h1 className="text-3xl font-bold underline">Welcome to Our University</h1>
      <p>Use Navbar to Navigate.</p>
    </div>
  )
}

export default HomePage
